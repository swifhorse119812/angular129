angularjs-tutorial
==================

Learn AngularJS in 30 minutes with this simple tutorial: [AngularJS Tutorial](http://www.revillweb.com/tutorials/angularjs-in-30-minutes-angularjs-tutorial/).
